# !pip install numpy
# !pip install pandas
# !pip install plotly
# !pip install scikit-learn
# !pip install gensim
# !pip install tqdm

import os
import sys
import re
import json
import gc
import gzip
import pickle
import time
import logging
from io import StringIO
from multiprocessing import Pool
from functools import partial
from typing import Tuple, Optional
from collections import Counter
import numpy as np
import pandas as pd
from gensim.models import FastText
from gensim.models.word2vec import Word2Vec
from sklearn.neighbors import NearestNeighbors
from tqdm import tqdm
from slg import SemanticLogGraphModel
from tools import read_logs

KEY_WORDS_SQL = ["select.+?from",
                 "select.+?as",
                 "select.+?union",
                 r"create\s+?table",
                 r"create\s+?view",
                 r"create\s+?local\s+?temp",
                 r"create\s+?projection",
                 r"create\s+?role",
                 r"create\s+?sequence",
                 r"create\s+?schema",
                 r"create\s+?or\s+?replace\s+?view",
                 r"creating\s+?default\s+?projection",
                 r"drop\s+?table",
                 r"drop\s+?view",
                 r"drop\s+?sequence",
                 "grant.+?to",
                 "grant.+?on",
                 r"comment\s+?on\s+?table",
                 r"comment\s+?on\s+?column",
                 r"drop_partitions\s+?on\s+?table",
                 r"alter\s+?table",
                 r"alter\s+?session",
                 r"alter\s+?sequence",
                 r"alter\s+?view",
                 r"alter\s+?schema",
                 "update.+?set",
                 r"delete\s+?from",
                 r"insert\s+?into",
                 r"truncate\s+?table",
                 "with.+?as",
                 "copy.+?from",
                 "copy.+?as",
                 r"copy\s+?table",
                 r"replicate\s+?table",
                 "merge.+?into",
                 r"check\s+?owner\s+?permissions\s+?on",
                 r"/\*"]
KEY_WORDS_SQL = '|'.join(KEY_WORDS_SQL)
REGEX = f'(?:{KEY_WORDS_SQL})'

TAGS_LIST_HDFS = ["INFO", "WARN"] # HDFS
KEY_WORDS_TAGS = '|'.join(TAGS_LIST_HDFS)
REGEX_TAGS_HDFS = f'(?:{KEY_WORDS_TAGS})'

class LogVectorizer:
    """Class with NLP model"""
    def __init__(self,
                 path_to_pretrained_nlp_model: str = None,
                 path_to_semantic_model: str = None,
                 download_model: bool = False,
                 model_path: str = "",
                 nlp_model_name: str = "fasttext",
                 use_words_tfidf: bool = True,
                 use_logs_tfidf: bool = True,
                 use_logs_patterns: bool = False,
                 tags_weights: dict = None,
                 patterns_weights: dict = None,
                 vector_size: int = 100,
                 window: int = 5,
                 min_count: int = 1,
                 epochs: int = 5,
                 time_interval: float = 1,
                 n_workers: int = 6,
                 log_file: str = None):
        self.__setup_logger(log_file)
        if nlp_model_name not in ['word2vec', 'fasttext']:
            self.logger.error("Unknown NLP model: %s", nlp_model_name)
            raise ValueError(f"Unknown NLP model: {nlp_model_name}")
        self.path_to_pretrained_nlp_model = path_to_pretrained_nlp_model
        self.path_to_semantic_model = path_to_semantic_model
        self.download_model = download_model
        self.model_path = model_path
        self.nlp_model_name = nlp_model_name
        self.use_words_tfidf = use_words_tfidf
        self.use_logs_tfidf = use_logs_tfidf
        self.use_logs_patterns = use_logs_patterns
        self.tags_weights = tags_weights
        self.patterns_weights = patterns_weights
        self.window = window
        self.vector_size = vector_size
        self.min_count = min_count
        self.epochs = epochs
        self.time_interval = time_interval
        self.n_workers = n_workers
        self.words_idf_dict = {}
        self.logs_idf_dict = {}
        self.words_tfidf_dict = {}
        self.logs_tfidf_dict = {}
        self.documents_count = 0

        if path_to_pretrained_nlp_model is not None:
            if "word2vec" in path_to_pretrained_nlp_model:
                self.logger.info("Loading pretrained word2vec model from: %s",
                                 path_to_pretrained_nlp_model)
                self.nlp_model = Word2Vec.load(path_to_pretrained_nlp_model)
            elif "fasttext" in path_to_pretrained_nlp_model:
                self.logger.info("Loading pretrained fasttext model from: %s",
                                 path_to_pretrained_nlp_model)
                self.nlp_model = FastText.load(path_to_pretrained_nlp_model)
            else:
                self.logger.error("Pretrained NLP model must have 'fasttext' or 'word2vec' in name")
                raise ValueError("Pretrained NLP model must have 'fasttext' or 'word2vec' in name")
        else:
            self.nlp_model = None

        if self.download_model:
            if self.nlp_model_name == 'word2vec':
                nlp_path = os.path.join(self.model_path,
                                        "nlp_model",
                                        "word2vec.model")
                self.logger.info("Loading word2vec model from: %s", nlp_path)
                self.nlp_model = Word2Vec.load(nlp_path)

            elif self.nlp_model_name == 'fasttext':
                nlp_path = os.path.join(self.model_path,
                                        "nlp_model",
                                        "fasttext.model")
                self.logger.info("Loading fasttext model from: %s", nlp_path)
                self.nlp_model = FastText.load(nlp_path)

            self.vector_size = self.nlp_model.vector_size
            self.window = self.nlp_model.window
            self.min_count = self.nlp_model.min_count

            words_idf_dict_path = os.path.join(self.model_path,
                                               "document_frequency",
                                               "words_document_frequency.gz")
            self.logger.info("Loading words idf dictionary from: %s", words_idf_dict_path)
            with gzip.open(words_idf_dict_path, mode='rb') as file:
                self.words_idf_dict = json.loads(file.read().decode('utf-8'))

            logs_idf_dict_path = os.path.join(self.model_path,
                                              "document_frequency",
                                              "logs_document_frequency.gz")
            self.logger.info("Loading logs idf dictionary from: %s", logs_idf_dict_path)
            with gzip.open(logs_idf_dict_path, mode='rb') as file:
                self.logs_idf_dict = json.loads(file.read().decode('utf-8'))

            documents_count_path = os.path.join(self.model_path,
                                                "document_frequency",
                                                "documents_count.txt")
            self.logger.info("Loading documents counter from: %s", documents_count_path)
            with open(documents_count_path, mode="r", encoding='utf-8') as file:
                self.documents_count = int(file.read())

    def __setup_logger(self,
                       log_file: str) -> None:
        self.logger = logging.getLogger("LogVectorizer")
        self.logger.handlers.clear()
        self.logger.setLevel(logging.DEBUG)
        formatter = logging.Formatter(
            '%(asctime)s [%(name)s] <%(levelname)s> - %(message)s')

        ch = logging.StreamHandler(sys.stdout) #console
        ch.setLevel(logging.DEBUG)
        ch.setFormatter(formatter)
        self.logger.addHandler(ch)

        if not log_file is None:
            fh = logging.FileHandler(log_file)
            fh.setLevel(logging.DEBUG)
            fh.setFormatter(formatter)
            self.logger.addHandler(fh)

    @staticmethod
    def split_log_pattern(log: str, dataset_type: str) -> list:
        """Splitting log by tag function"""
        if dataset_type == "HDFS":
            tag = re.findall(REGEX_TAGS_HDFS, log)[0]
        return log.split(tag)[1].split()

    @staticmethod
    def calc_groups_by_interval(logs_group_df):
        """Counter functions in groups"""
        # Расчёт bag of logs
        patterns_group_df = logs_group_df["log_pattern"].value_counts()
        patterns_group_dict = {key: int(value) for key, value in dict(patterns_group_df).items()}
        # Расчёт bag of words и idf_dict
        counter_words = Counter()
        logs_group_df["log_pattern"].apply(partial(LogVectorizer.split_log_pattern, dataset_type="HDFS")).\
                                     apply(counter_words.update)
        return patterns_group_dict, dict(counter_words),\
               list(patterns_group_df.index), list(counter_words.keys())

    def __calc_bol_corpus(self,
                          logs_df: pd.DataFrame,
                          inference_mode: bool = False) -> Tuple[list, pd.DataFrame]:
        timestamp = pd.DatetimeIndex(logs_df.index,
                                     dtype='datetime64[s]').floor(f'{self.time_interval}min')
        # split_ts = np.array(list(pd.date_range(start=timestamp[0],
        #                                         end=timestamp[-1],
        #                                         freq=f"{self.time_interval}min")),
        #                     dtype='datetime64[s]')
        split_ts = timestamp.unique()
        logs_split_df = pd.DataFrame(index=split_ts[:-1], columns=['logs_count'])

        # Расчет встречамости фраз из системной части по временным интервалам
        logs_df["interval"] = pd.cut(logs_df.index, bins=split_ts, include_lowest=True, right=False)
        logs_df = logs_df.dropna(subset=['interval'])

        logs_split_df["logs_count"] = logs_df.groupby("interval",
                                                      observed=False)["tag"].count().values

        grouped_logs_df = logs_df.groupby(["interval",
                                           "tag"],
                                           observed=False)["log_pattern"].count().unstack(level=1)
        grouped_logs_df.index = split_ts[:-1]
        grouped_logs_df.columns.name = None

        logs_split_df = pd.concat([logs_split_df,
                                   grouped_logs_df],
                                  axis=1)

        # Расчёт bag of words, bag of logs, words_idf_dict и logs_idf_dict
        bol_corpus, bow_corpus, cur_logs_idf_dict, cur_words_idf_dict = zip(
                                *logs_df.groupby("interval", observed=False).\
                                         apply(LogVectorizer.calc_groups_by_interval))
        bol_corpus = dict(zip(split_ts[:-1].astype('str'), bol_corpus))
        bow_corpus = dict(zip(split_ts[:-1].astype('str'), bow_corpus))

        if not inference_mode:
            self.documents_count += len(bow_corpus)

            cnt = Counter(self.words_idf_dict)
            for log_int in cur_words_idf_dict:
                if len(log_int) != 0:
                    cnt.update(log_int)
            self.words_idf_dict = dict(cnt)

            cnt = Counter(self.logs_idf_dict)
            for log_int in cur_logs_idf_dict:
                if len(log_int) != 0:
                    cnt.update(log_int)
            self.logs_idf_dict = dict(cnt)
        return bol_corpus, bow_corpus, logs_split_df

    def fit(self,
            logs_df: pd.DataFrame) -> Tuple[list, pd.DataFrame]:
        """Fitting NLP model function"""
        if self.epochs != 0:
            self.logger.info("Start logs splitting")
            start_time = time.time()
            data_splited = list(logs_df["log_pattern"].apply(partial(LogVectorizer.split_log_pattern, dataset_type="HDFS")).values)
            self.logger.info("Finished logs splitting, time: %s sec",
                            np.round(time.time() - start_time, 2))

        self.logger.info("Start NLP model (%s) fitting", self.nlp_model_name)
        start_time = time.time()
        if self.download_model | (self.path_to_pretrained_nlp_model is not None):
            if self.epochs != 0:
                self.nlp_model.build_vocab(data_splited, update=True)
                self.nlp_model.train(data_splited, total_examples=len(data_splited),
                                     epochs=self.epochs)
        else:
            if self.epochs == 0:
                self.logger.error("The number of epochs must be greater than 0 "
                                  "when training a model from scratch")
                raise ValueError("The number of epochs must be greater than 0 "
                                 "when training a model from scratch")
            if self.nlp_model_name == 'word2vec':
                self.nlp_model = Word2Vec(data_splited,
                                        vector_size=self.vector_size,
                                        window=self.window,
                                        min_count=self.min_count,
                                        epochs=self.epochs,
                                        workers=self.n_workers)
            elif self.nlp_model_name == 'fasttext':
                self.nlp_model = FastText(data_splited,
                                        vector_size=self.vector_size,
                                        window=self.window,
                                        min_count=self.min_count,
                                        epochs=self.epochs,
                                        workers=self.n_workers)
        self.logger.info("Finished NLP model (%s) fitting, time: %s sec",
                         self.nlp_model_name, np.round(time.time() - start_time, 2))

        self.logger.info("Start bags of words and logs corpus calculation")
        start_time = time.time()
        bol_corpus, bow_corpus, logs_split_df = self.__calc_bol_corpus(logs_df)
        self.logger.info("Finished bags of word and logs corpus calculation, time: %s sec",
                         np.round(time.time() - start_time, 2))
        return bol_corpus, bow_corpus, logs_split_df

    def __load_log_corpus(self,
                          corpus_type: str = "bag_of_words",
                          path_to_results: Optional[str] = None) -> dict:
        if corpus_type == "bag_of_words":
            file_startswith = "bow_corpus"
        elif corpus_type == "bag_of_logs":
            file_startswith = "bol_corpus"

        if path_to_results is None:
            files_list = os.listdir(os.path.abspath(os.path.join(self.model_path, "train_info")))
        else:
            files_list = os.listdir(os.path.abspath(os.path.join(path_to_results, "test_info")))
        files = sorted([file for file in files_list if file.startswith(file_startswith)])

        log_corpus = {}
        for file in files:
            if path_to_results is None:
                log_corpus_path = os.path.abspath(os.path.join(self.model_path,
                                                               "train_info",
                                                               file))
            else:
                log_corpus_path = os.path.abspath(os.path.join(path_to_results,
                                                               "test_info",
                                                               file))
            with gzip.open(log_corpus_path, mode='rb') as file:
                log_corpus_file = json.loads(file.read().decode('utf-8'))
            log_corpus.update(log_corpus_file)
        if (self.documents_count != len(log_corpus)) & (path_to_results is None):
            self.logger.error("Length of %s corpus (=%s) is not equal to documents_count (=%s)",
                              corpus_type, len(log_corpus), self.documents_count)
            raise ValueError(f"Length of {corpus_type} corpus (={len(log_corpus)}) is not equal to "
                             f"documents_count (={self.documents_count})")
        return log_corpus

    def __calc_tfidf_dict(self,
                          corpus: dict,
                          n_docs: int,
                          corpus_type: str,
                          inference_mode: bool = False) -> None:
        for ts, doc in corpus.items():
            n_doc = sum(doc.values())
            tfidf_doc = {}
            for item, count in doc.items():
                tf = count / n_doc
                if inference_mode:
                    if corpus_type == "bag_of_logs":
                        if item in self.logs_idf_dict:
                            idf = np.log2((n_docs + 2) / (self.logs_idf_dict[item] + 1))
                        else:
                            idf = np.log2(n_docs + 2)
                    else:
                        if item in self.words_idf_dict:
                            idf = np.log2((n_docs + 2) / (self.words_idf_dict[item] + 1))
                        else:
                            idf = np.log2(n_docs + 2)
                else:
                    if corpus_type == "bag_of_logs":
                        idf = np.log2((n_docs + 1) / self.logs_idf_dict[item])
                    else:
                        idf = np.log2((n_docs + 1) / self.words_idf_dict[item])
                tfidf_doc[item] = tf * idf
            w_norm = np.sqrt((np.array(list(tfidf_doc.values()))**2).sum())
            for item in tfidf_doc:
                tfidf_doc[item] = tfidf_doc[item] / w_norm
            if corpus_type == "bag_of_logs":
                self.logs_tfidf_dict[ts] = tfidf_doc
            elif corpus_type == "bag_of_words":
                self.words_tfidf_dict[ts] = tfidf_doc

    def log_weight_calc(self,
                        log: str,
                        tag: str) -> float:
        """Logs weights calculation by log patterns and tags"""
        weight = 1.0
        if self.patterns_weights is not None:
            if log in self.patterns_weights:
                weight *= self.patterns_weights[log]
        if self.tags_weights is not None:
            if tag in self.tags_weights:
                weight *= self.tags_weights[tag]
            else:
                self.logger.warning("A new tag was met: %s. It was given a weight: %s",
                                    tag, self.tags_weights["###UNKNOWN_TAG"])
                self.tags_weights[tag] = self.tags_weights["###UNKNOWN_TAG"]
                weight *= self.tags_weights["###UNKNOWN_TAG"]
        return weight

    @staticmethod
    def find_tag(logtext: str, dataset_type: str) -> str:
        if dataset_type == "HDFS":
            tag = re.findall(REGEX_TAGS_HDFS, logtext)[0]
        return tag

    def __doc_to_vec(self,
                     bol_corpus: dict,
                     calc_logs_importance: bool = False) -> Tuple[np.ndarray, pd.DataFrame]:
        logs_importance_df = []
        doc_vectors = np.zeros((len(bol_corpus), self.vector_size))
        i = 0
        for ts, doc in tqdm(bol_corpus.items()):
            doc_vector = np.zeros(self.vector_size)
            doc_num_logs = 0
            if calc_logs_importance:
                log_vectors = []
                tag_list = []
            for log, n_logs in doc.items():
                tag = LogVectorizer.find_tag(log, dataset_type="HDFS")
                log_vector = np.zeros(self.vector_size)
                log_num_words = 0
                for word in log.split(tag)[1].split():
                    if ((self.nlp_model_name == "word2vec") & (word in self.nlp_model.wv)) | \
                        (self.nlp_model_name == "fasttext"):
                        if self.use_words_tfidf:
                            log_vector += self.nlp_model.wv[word] * self.words_tfidf_dict[ts][word]
                        else:
                            log_vector += self.nlp_model.wv[word]
                        log_num_words += 1
                if self.use_logs_tfidf:
                    log_vector *= self.logs_tfidf_dict[ts][log]
                if self.use_logs_patterns:
                    log_vector *= self.log_weight_calc(log, tag)
                if log_num_words != 0:
                    log_vector /= log_num_words
                doc_vector += log_vector * n_logs
                doc_num_logs += n_logs
                if calc_logs_importance:
                    log_vectors.append(log_vector * n_logs)
                    tag_list.append(tag)
            if doc_num_logs != 0:
                doc_vector /= doc_num_logs
                if calc_logs_importance:
                    log_vectors = np.array(log_vectors) / doc_num_logs
                    logs_importance = (doc_vector @ log_vectors.T) / np.linalg.norm(doc_vector)**2
                    logs_importance_df.extend(zip([ts] * len(doc),
                                                  list(doc.keys()),
                                                  tag_list,
                                                  list(doc.values()),
                                                  logs_importance))
            else:
                doc_vector = np.full(self.vector_size, np.nan)
            doc_vectors[i] = doc_vector
            i += 1
        logs_importance_df = pd.DataFrame(logs_importance_df,
                                          columns=["timestamp",
                                                   "log_pattern",
                                                   "tag",
                                                   "quantity",
                                                   "log_importance"])
        if calc_logs_importance:
            logs_importance_df["timestamp"] = pd.to_datetime(logs_importance_df["timestamp"])
            logs_importance_df["% of all"] = logs_importance_df.groupby("timestamp").apply(
                                                lambda x: x["quantity"] / x["quantity"].sum() * 100
                                                                        ).reset_index()["quantity"]
            logs_importance_df = logs_importance_df.sort_values(["timestamp", "log_importance"],
                                                    ascending=[True, False]).reset_index(drop=True)
        return doc_vectors, logs_importance_df

    def __parallel_doc_to_vec(self,
                              log_corpus: dict,
                              calc_logs_importance: bool = False) -> Tuple[np.ndarray,
                                                                           pd.DataFrame]:
        random_indexes = np.random.RandomState(42).choice(np.arange(len(log_corpus)),
                                                        len(log_corpus),
                                                        replace=False)
        splitted_keys = np.array_split(np.array(list(log_corpus.keys()))[random_indexes],
                                       self.n_workers)

        splitted_dict = []
        for i in range(self.n_workers):
            log_corpus_i = {}
            for key in splitted_keys[i]:
                log_corpus_i[key] = log_corpus[key]
            splitted_dict.append(log_corpus_i)
        with Pool(self.n_workers) as pool:
            doc_vectors, logs_importance_df = zip(*pool.map(partial(
                                                        self.__doc_to_vec,
                                                        calc_logs_importance=calc_logs_importance
                                                                   ),
                                                            splitted_dict))

        sorted_indexes = np.argsort(random_indexes)
        doc_vectors = np.concatenate(doc_vectors)[sorted_indexes]
        logs_importance_df = pd.concat(logs_importance_df).sort_values(["timestamp",
                                                                        "log_importance"],
                                                ascending=[True, False]).reset_index(drop=True)
        logs_importance_df["% of all"] = logs_importance_df.groupby("timestamp").apply(
                                                lambda x: x["quantity"] / x["quantity"].sum() * 100
                                                                        ).reset_index()["quantity"]
        return doc_vectors, logs_importance_df

    def __load_logs_split_df(self,
                             path_to_results: str = None) -> pd.DataFrame:
        if path_to_results is None:
            info_folder_path = os.path.join(self.model_path, "train_info")
        else:
            info_folder_path = os.path.join(path_to_results, "test_info")

        files = sorted([file for file in os.listdir(info_folder_path) if \
                        file.startswith('logs_split_df')])
        logs_split_df = pd.DataFrame()
        for file in files:
            logs_split_df_path = os.path.join(info_folder_path, file)
            logs_split_df_i = pd.read_csv(logs_split_df_path, encoding='utf-8', index_col=0)
            if logs_split_df is None:
                logs_split_df = logs_split_df_i
            else:
                logs_split_df = pd.concat([logs_split_df, logs_split_df_i])
        logs_split_df.fillna(0, inplace=True)
        logs_split_df = logs_split_df.astype(int)
        logs_split_df.index = pd.to_datetime(logs_split_df.index)
        return logs_split_df

    def calc_train_vectors(self,
                           parallel_mode: Optional[bool] = False) -> pd.DataFrame:
        """TfIdf dictionary saving and train vectors calculation function"""
        if self.use_words_tfidf:
            self.logger.info("Loading train bag of words corpus from folder: %s",
                            os.path.join(self.model_path, "train_info"))
            bow_corpus = self.__load_log_corpus(corpus_type="bag_of_words")

            self.logger.info("Start words TfIdf dictionary calculation")
            start_time = time.time()
            self.__calc_tfidf_dict(bow_corpus, n_docs=len(bow_corpus), corpus_type="bag_of_words")
            self.logger.info("Finished words TfIdf dictionary calculation, time: %s sec",
                             np.round(time.time() - start_time, 2))

            gc.collect()
            del bow_corpus

        self.logger.info("Loading train bag of logs corpus from folder: %s",
                         os.path.join(self.model_path, "train_info"))
        bol_corpus = self.__load_log_corpus(corpus_type="bag_of_logs")

        if self.use_logs_tfidf:
            self.logger.info("Start logs TfIdf dictionary calculation")
            start_time = time.time()
            self.__calc_tfidf_dict(bol_corpus, n_docs=len(bol_corpus), corpus_type="bag_of_logs")
            self.logger.info("Finished logs TfIdf dictionary calculation, time: %s sec",
                             np.round(time.time() - start_time, 2))

        self.logger.info("Start %s calculation", self.nlp_model_name)
        start_time = time.time()
        if parallel_mode:
            self.logger.info("Using %s workers for parallel calculations", self.n_workers)
            doc_vectors, _ = self.__parallel_doc_to_vec(bol_corpus)
        else:
            doc_vectors, _ = self.__doc_to_vec(bol_corpus)
        self.logger.info("Finished %s calculation, time: %s sec", self.nlp_model_name,
                         np.round(time.time() - start_time, 2))

        self.logger.info("Loading logs counter from folder: %s", os.path.join(self.model_path,
                                                                              "train_info"))
        logs_split_df = self.__load_logs_split_df()

        vectors_df = pd.DataFrame(doc_vectors,
                                  index=logs_split_df.index,
                                  columns=[f"vector_{i + 1}" for i in range(self.vector_size)])
        vectors_df = pd.merge(vectors_df,
                              logs_split_df,
                              left_index=True,
                              right_index=True)
        return vectors_df

    def calc_test_vectors(self,
                          logs_df: Optional[pd.DataFrame] = None,
                          path_to_results: Optional[str] = None,
                          calc_logs_importance: Optional[bool] = False,
                          parallel_mode: Optional[bool] = False,
                          ) -> pd.DataFrame:
        """Test vectors calculation function"""

        if path_to_results is None:
            self.logger.info("Start bags of words and logs corpus calculation")
            start_time = time.time()
            bol_corpus, bow_corpus, logs_split_df = self.__calc_bol_corpus(logs_df,
                                                                           inference_mode=True)
            self.logger.info("Finished bags of word and logs corpus calculation, time: %s sec",
                             np.round(time.time() - start_time, 2))
        else:
            self.logger.info("Loading logs counter from folder: %s", os.path.join(path_to_results,
                                                                                  "test_info"))
            logs_split_df = self.__load_logs_split_df(path_to_results)

            self.logger.info("Loading test bag of words corpus from: %s",
                             os.path.join(self.model_path, "test_info"))
            bow_corpus = self.__load_log_corpus(corpus_type="bag_of_words",
                                                path_to_results=path_to_results)

            self.logger.info("Loading test bag of logs corpus from: %s",
                             os.path.join(self.model_path, "test_info"))
            bol_corpus = self.__load_log_corpus(corpus_type="bag_of_logs",
                                                path_to_results=path_to_results)

        self.logger.info("Start words TfIdf dictionary calculation")
        self.__calc_tfidf_dict(bow_corpus, n_docs=self.documents_count,
                               corpus_type="bag_of_words", inference_mode=True)

        self.logger.info("Start logs TfIdf dictionary calculation")
        self.__calc_tfidf_dict(bol_corpus, n_docs=self.documents_count,
                               corpus_type="bag_of_logs", inference_mode=True)

        self.logger.info("Start %s calculation", self.nlp_model_name)
        start_time = time.time()
        if parallel_mode:
            self.logger.info("Using %s workers for parallel calculations", self.n_workers)
            doc_vectors, logs_importance_corpus = self.__parallel_doc_to_vec(
                                                        bol_corpus,
                                                        calc_logs_importance=calc_logs_importance)
        else:
            doc_vectors, logs_importance_corpus = self.__doc_to_vec(
                                                        bol_corpus,
                                                        calc_logs_importance=calc_logs_importance)
        self.logger.info("Finished %s calculation, time: %s sec", self.nlp_model_name,
                         np.round(time.time() - start_time, 2))

        test_vectors_df = pd.DataFrame(doc_vectors,
                                       index=logs_split_df.index,
                                       columns=[f"vector_{i + 1}" for i in range(self.vector_size)])
        test_vectors_df = pd.merge(test_vectors_df,
                                   logs_split_df,
                                   left_index=True,
                                   right_index=True)
        return test_vectors_df, bol_corpus, bow_corpus, logs_split_df, logs_importance_corpus

class LogAnalysis:
    """Class with logs analysis model"""
    def __init__(self,
                 download_model: bool = False,
                 path_to_model: str = "",
                 path_to_semantic_model: str = "",
                 nlp_model_name: str = "fasttext",
                 use_words_tfidf: bool = True,
                 use_logs_tfidf: bool = True,
                 use_logs_patterns: bool = False,
                 tags_weights: dict = None,
                 patterns_weights: dict = None,
                 vector_size: int = 100,
                 window: int = 5,
                 min_count: int = 1,
                 epochs: int = 5,
                 time_interval: int = 1,
                 n_workers: int = 6,
                 n_nearest_nbrs: int = 7,
                 quantile_mean_dist: float = 0.95,
                 save_train_info: bool = True,
                 log_file: str = None,
                 log_analysis_model_name: Optional[str] = "log_analysis_model.json",
                 knn_model_name: Optional[str] = "knn_model.pickle",
                 doc_vectors_name: Optional[str] = "doc_vectors.csv"):
        self.download_model = download_model
        self.path_to_model = path_to_model
        self.path_to_semantic_model = path_to_semantic_model
        self.log_analysis_model_name = log_analysis_model_name
        self.log_file = log_file
        self.__setup_logger(log_file)

        if download_model:
            log_analysis_model_path = os.path.join(path_to_model, self.log_analysis_model_name)
            self.logger.info("Loading log analysis model from: %s", log_analysis_model_path)
            with open(log_analysis_model_path, mode="r", encoding='utf-8') as opened_file:
                log_analysis_model = json.load(opened_file, parse_int=int)

            self.nlp_model_name = log_analysis_model.get("nlp_model_name", "fasttext")
            self.use_words_tfidf = log_analysis_model.get("use_words_tfidf", True)
            self.use_logs_tfidf = log_analysis_model.get("use_logs_tfidf", False)
            self.use_logs_patterns = log_analysis_model.get("use_logs_patterns", False)
            self.tags_weights = log_analysis_model.get("tags_weights", None)
            self.patterns_weights = log_analysis_model.get("patterns_weights", None)
            self.vector_size = log_analysis_model.get("vector_size", 100)
            self.window = log_analysis_model.get("window", 5)
            self.min_count = log_analysis_model.get("min_count", 1)
            self.epochs = log_analysis_model.get("epochs", 5)
            self.time_interval = log_analysis_model.get("time_interval", 1)
            self.n_workers = log_analysis_model.get("n_workers", 6)
            self.n_nearest_nbrs = log_analysis_model.get("n_nearest_nbrs", 7)
            self.quantile_mean_dist = log_analysis_model.get("quantile_mean_dist", 0.95)
            self.save_train_info = log_analysis_model.get("save_train_info", True)
            self.mean_distances = pd.read_json(StringIO(log_analysis_model.get("mean_distances",
                                                                               None)),
                                               typ='series')
            self.treshold_score = log_analysis_model.get("treshold_score", 0)
            self.fitted = log_analysis_model.get("fitted", True)
            self.knn_model_name = log_analysis_model.get("knn_model_name", "knn_model.pickle")
            self.doc_vectors_name = log_analysis_model.get("doc_vectors_name",
                                                           "doc_vectors.csv")
        else:
            if os.path.exists(os.path.join(self.path_to_model, self.log_analysis_model_name)):
                self.logger.info("Log analysis model has already created. "
                                 "This model will be rewritten.")
            self.nlp_model_name = nlp_model_name
            self.use_words_tfidf = use_words_tfidf
            self.use_logs_tfidf = use_logs_tfidf
            self.use_logs_patterns = use_logs_patterns
            self.tags_weights = tags_weights
            self.patterns_weights = patterns_weights
            self.vector_size = vector_size
            self.window = window
            self.min_count = min_count
            self.epochs = epochs
            self.time_interval = time_interval
            self.n_workers = n_workers
            self.n_nearest_nbrs = n_nearest_nbrs
            self.quantile_mean_dist = quantile_mean_dist
            self.save_train_info = save_train_info
            self.mean_distances = None
            self.treshold_score = None
            self.fitted = False
            self.knn_model_name = knn_model_name
            self.doc_vectors_name = doc_vectors_name

        self.logger.info("Model parameter 'download_model' = %s", self.download_model)
        self.logger.info("Model parameter 'path_to_model' = %s", self.path_to_model)
        self.logger.info("Model parameter 'log_analysis_model_name' = %s", log_analysis_model_name)
        self.logger.info("Model parameter 'path_to_semantic_model' = %s",
                         self.path_to_semantic_model)
        self.logger.info("Model parameter 'nlp_model_name' = %s", self.nlp_model_name)
        self.logger.info("Model parameter 'use_words_tfidf' = %s", self.use_words_tfidf)
        self.logger.info("Model parameter 'use_logs_tfidf' = %s", self.use_logs_tfidf)
        self.logger.info("Model parameter 'use_logs_patterns' = %s", self.use_logs_patterns)
        self.logger.info("Model parameter 'tags_weights' = %s", self.tags_weights)
        self.logger.info("Model parameter 'patterns_weights' = %s", self.patterns_weights)
        self.logger.info("Model parameter 'vector_size' = %s", self.vector_size)
        self.logger.info("Model parameter 'window' = %s", self.window)
        self.logger.info("Model parameter 'min_count' = %s", self.min_count)
        self.logger.info("Model parameter 'epochs' = %s", self.epochs)
        self.logger.info("Model parameter 'time_interval' = %s", self.time_interval)
        self.logger.info("Model parameter 'n_workers' = %s", self.n_workers)
        self.logger.info("Model parameter 'n_nearest_nbrs' = %s", self.n_nearest_nbrs)
        self.logger.info("Model parameter 'quantile_mean_dist' = %s", self.quantile_mean_dist)
        self.logger.info("Model parameter 'save_train_info' = %s", self.save_train_info)
        self.logger.info("Model parameter 'knn_model_name' = %s", self.knn_model_name)
        self.logger.info("Model parameter 'doc_vectors_name' = %s",
                         self.doc_vectors_name)
        if download_model:
            self.logger.info("Model parameter 'treshold_score' = %s", self.treshold_score)
            self.logger.info("Model parameter 'fitted' = %s", self.fitted)

        if use_logs_patterns & (tags_weights is None) & (patterns_weights is None):
            self.logger.error("tags_weights or patterns_weights must not be None if "
                              "use_logs_patterns is True")
            raise ValueError("tags_weights or patterns_weights must not be None if "
                             "use_logs_patterns is True")

    def __setup_logger(self,
                       log_file: str) -> None:
        self.logger = logging.getLogger("LogAnalysis")
        self.logger.handlers.clear()
        self.logger.setLevel(logging.DEBUG)
        formatter = logging.Formatter(
            '%(asctime)s [%(name)s] <%(levelname)s> - %(message)s')

        ch = logging.StreamHandler(sys.stdout) #console
        ch.setLevel(logging.DEBUG)
        ch.setFormatter(formatter)
        self.logger.addHandler(ch)

        if log_file is not None:
            fh = logging.FileHandler(log_file)
            fh.setLevel(logging.DEBUG)
            fh.setFormatter(formatter)
            self.logger.addHandler(fh)

    def __log_preprocessing(self,
                            logs: list,
                            dataset_type: str,
                            delete_sql: bool=False) -> Tuple[pd.DataFrame, list]:
        """Log preprocessing function"""
        with open(self.path_to_semantic_model, 'rb') as handle:
            slg_model = pickle.load(handle)

        if dataset_type == "HDFS":
            tags_list = TAGS_LIST_HDFS

        log_pattern_list = []
        ts_list = []
        tag_list = []
        for raw_log in tqdm(logs):
            if delete_sql:
                search_res = re.search(REGEX,
                                       re.sub("\n", " ", raw_log),
                                       re.IGNORECASE)
                if search_res is not None:
                    raw_log = raw_log[:search_res.start()]
            ts, log = slg_model.preprocess_logline_tokens(raw_log)
            for i, word in enumerate(log):
                if word in tags_list:
                    if (len(log) - i - 1) >= self.window:
                        log_pattern_list.append(" ".join(log))
                        ts_list.append(ts)
                        tag_list.append(word)
                    break
        timestamp = np.array(ts_list, dtype='datetime64[s]')

        logs_df = pd.DataFrame(index=timestamp)
        logs_df["log_pattern"] = log_pattern_list
        logs_df["tag"] = tag_list
        return logs_df

    def __sorting_check(self,
                        logs_df: pd.DataFrame) -> Tuple[pd.DataFrame, list]:
        timestamp = logs_df.index.to_numpy()
        if not all(timestamp[i] <= timestamp[i + 1] for i in range(len(timestamp) - 1)):
            self.logger.warning("Dataset is not sorted, start sorting the dataset")
            sort_indexes = np.argsort(timestamp)
            logs_df = logs_df.iloc[sort_indexes]
        return logs_df

    def __split_list(self,
                     lst: list) -> list:
        """Splitting list to n_workers parts function"""
        n = int(len(lst) / self.n_workers)
        return [lst[i:i + n] for i in range(0, len(lst), n)]

    def __parallel_log_preprocessing(self,
                                     logs: list) -> Tuple[pd.DataFrame, list]:
        """Parallel log preprocessing function"""
        splited_logs = self.__split_list(logs)
        with Pool(self.n_workers) as pool:
            logs_df = pool.map(partial(self.__log_preprocessing, dataset_type="HDFS"), splited_logs)
        logs_df = pd.concat(logs_df)
        return logs_df

    def __calc_mean_distances(self,
                              doc_vectors: pd.DataFrame,
                              mode: str = 'train') -> pd.Series:
        if mode == 'train':
            nbrs = NearestNeighbors(n_neighbors=self.n_nearest_nbrs + 1).fit(doc_vectors.values)

            self.logger.info("Saving knn model to: %s",
                             os.path.join(self.path_to_model, self.knn_model_name))
            knn_pickle = open(os.path.join(self.path_to_model,
                                           self.knn_model_name),
                              'wb')
            pickle.dump(nbrs, knn_pickle)
            knn_pickle.close()

            distances, _ = nbrs.kneighbors(doc_vectors.values)
            mean_distances = pd.Series(distances[:, 1:].mean(axis=1),
                                       index=doc_vectors.index)
        else:
            self.logger.info("Loading knn model from: %s",
                             os.path.join(self.path_to_model, self.knn_model_name))
            nbrs = pickle.load(open(os.path.join(self.path_to_model,
                                                 self.knn_model_name),
                                    'rb'))

            distances, _ = nbrs.kneighbors(doc_vectors.values)
            mean_distances = pd.Series(distances.mean(axis=1),
                                       index=doc_vectors.index)
        return mean_distances

    def fit(self,
            path_to_files: Optional[list] = None,
            path_to_pretrained_nlp_model: Optional[str] = None,
            skip_fitting_nlp_model: Optional[bool] = False,
            skip_calc_vectors: Optional[bool] = False,
            parallel_mode: Optional[bool] = False) -> None:
        """Fit function"""
        if (path_to_files is None) & (skip_fitting_nlp_model is False) & \
                                                                    (skip_calc_vectors is False):
            self.logger.error("skip_fitting_nlp_model or skip_calc_vectors must be True "
                              "if path_to_data or files is None")
            raise ValueError("skip_fitting_nlp_model or skip_calc_vectors must be True "
                             "if path_to_data or files is None")
        if (path_to_files is not None) & ((skip_fitting_nlp_model is True) | \
                                                                    (skip_calc_vectors is True)):
            self.logger.error("skip_fitting_nlp_model or skip_calc_vectors must be False "
                              "if path_to_data or files is not None")
            raise ValueError("skip_fitting_nlp_model or skip_calc_vectors must be False "
                             "if path_to_data or files is not None")
        if (skip_fitting_nlp_model is True) & (skip_calc_vectors is True):
            self.logger.error("skip_fitting_nlp_model and skip_calc_vectors cannot be True "
                              "at the same time")
            raise ValueError("skip_fitting_nlp_model and skip_calc_vectors cannot be True "
                             "at the same time")

        if (not skip_fitting_nlp_model) & (not skip_calc_vectors):
            for path_to_file in path_to_files:
                self.logger.info("Start training from file: %s", path_to_file)
                if len(re.findall("[0-9]", path_to_file)) != 0:
                    suffix = re.findall("[0-9]", path_to_file)[0]
                else:
                    suffix = "1"
                self.logger.info("Start reading log file: %s", path_to_file)
                logs = read_logs(path_to_file, "HDFS") # hardcode
                self.logger.info("Start preprocessing log file: %s", path_to_file)
                start_time = time.time()
                if parallel_mode:
                    self.logger.info("Using %s workers for parallel calculation", self.n_workers)
                    logs_df = self.__parallel_log_preprocessing(logs)
                else:
                    logs_df = self.__log_preprocessing(logs, dataset_type="HDFS")
                logs_df = self.__sorting_check(logs_df)
                self.logger.info("Finished preprocessing log file, time: %s sec",
                                 np.round(time.time() - start_time, 2))

                if not os.path.exists(os.path.join(self.path_to_model, "nlp_model")):
                    self.logger.info("Log analysis model not found, creating new model")
                    os.makedirs(os.path.join(self.path_to_model, "train_info"))
                    os.makedirs(os.path.join(self.path_to_model, "nlp_model"))
                    os.makedirs(os.path.join(self.path_to_model, "document_frequency"))

                    # inicialize vectorizer
                    log_vectorizer = LogVectorizer(
                                        path_to_pretrained_nlp_model=path_to_pretrained_nlp_model,
                                        path_to_semantic_model=self.path_to_semantic_model,
                                        nlp_model_name=self.nlp_model_name,
                                        use_words_tfidf=self.use_words_tfidf,
                                        use_logs_tfidf=self.use_logs_tfidf,
                                        use_logs_patterns=self.use_logs_patterns,
                                        tags_weights=self.tags_weights,
                                        patterns_weights=self.patterns_weights,
                                        vector_size=self.vector_size,
                                        window=self.window,
                                        min_count=self.min_count,
                                        epochs=self.epochs,
                                        time_interval=self.time_interval,
                                        n_workers=self.n_workers,
                                        log_file=self.log_file)
                else:
                    self.logger.info("Using log analysis model: %s", self.path_to_model)
                    # inicialize vectorizer
                    log_vectorizer = LogVectorizer(download_model=True,
                                                   model_path=self.path_to_model,
                                                   path_to_semantic_model=self.path_to_semantic_model,
                                                   nlp_model_name=self.nlp_model_name,
                                                   use_words_tfidf=self.use_words_tfidf,
                                                   use_logs_tfidf=self.use_logs_tfidf,
                                                   use_logs_patterns=self.use_logs_patterns,
                                                   tags_weights=self.tags_weights,
                                                   patterns_weights=self.patterns_weights,
                                                   epochs=self.epochs,
                                                   time_interval=self.time_interval,
                                                   n_workers=self.n_workers,
                                                   log_file=self.log_file)
                # fit vectorizer
                start_time = time.time()
                bol_corpus, bow_corpus, logs_split_df = log_vectorizer.fit(logs_df)
                self.logger.info("Finished log analysis model fitting, time: %s sec",
                                 np.round(time.time() - start_time, 2))

                self.logger.info("Model updating")

                # save nlp model
                if self.nlp_model_name == "word2vec":
                    full_nlp_model_name = "word2vec.model"
                else:
                    full_nlp_model_name = "fasttext.model"
                nlp_path = os.path.join(self.path_to_model,
                                        "nlp_model",
                                        full_nlp_model_name)
                log_vectorizer.nlp_model.save(nlp_path)

                # save words_idf_dict
                words_idf_dict_path = os.path.join(self.path_to_model,
                                             "document_frequency",
                                             "words_document_frequency.gz")
                with gzip.open(words_idf_dict_path, mode='wb') as opened_file:
                    opened_file.write(json.dumps(log_vectorizer.words_idf_dict,
                                                 indent=True).encode('utf-8'))

                # save logs_idf_dict
                logs_idf_dict_path = os.path.join(self.path_to_model,
                                             "document_frequency",
                                             "logs_document_frequency.gz")
                with gzip.open(logs_idf_dict_path, mode='wb') as opened_file:
                    opened_file.write(json.dumps(log_vectorizer.logs_idf_dict,
                                                 indent=True).encode('utf-8'))

                # save bol corpus
                bol_corpus_path = os.path.join(self.path_to_model,
                                              "train_info",
                                              f"bol_corpus_{suffix}.gz")
                with gzip.open(bol_corpus_path, mode='wb') as opened_file:
                    opened_file.write(json.dumps(bol_corpus, indent=True).encode('utf-8'))

                # save bow corpus
                bow_corpus_path = os.path.join(self.path_to_model,
                                              "train_info",
                                              f"bow_corpus_{suffix}.gz")
                with gzip.open(bow_corpus_path, mode='wb') as opened_file:
                    opened_file.write(json.dumps(bow_corpus, indent=True).encode('utf-8'))

                # save logs_split_df
                logs_split_df_path = os.path.join(self.path_to_model,
                                                  "train_info",
                                                  f"logs_split_df_{suffix}.csv")
                logs_split_df.to_csv(logs_split_df_path, encoding='utf-8')

                # documents_count
                with open(os.path.join(self.path_to_model,
                                       "document_frequency", 
                                       "documents_count.txt"), mode="w", encoding='utf-8') as file:
                    file.write(str(log_vectorizer.documents_count))

                gc.collect()
                del logs, logs_df, bol_corpus, log_vectorizer, logs_split_df

        if not skip_calc_vectors:
            self.logger.info("Start train vectors calculation")
            log_vectorizer = LogVectorizer(download_model=True,
                                           model_path=self.path_to_model,
                                           path_to_semantic_model=self.path_to_semantic_model,
                                           nlp_model_name=self.nlp_model_name,
                                           use_words_tfidf=self.use_words_tfidf,
                                           use_logs_tfidf=self.use_logs_tfidf,
                                           use_logs_patterns=self.use_logs_patterns,
                                           tags_weights=self.tags_weights,
                                           patterns_weights=self.patterns_weights,
                                           log_file=self.log_file)
            start_time = time.time()
            doc_vectors = log_vectorizer.calc_train_vectors(parallel_mode=parallel_mode)
            self.logger.info("Finished train vectors calculation, time: %s sec",
                             np.round(time.time() - start_time, 2))

            if self.save_train_info:
                self.logger.info("Saving training vectors to folder: %s", self.path_to_model)
                doc_vectors.to_csv(os.path.join(self.path_to_model,
                                                self.doc_vectors_name))
            else:
                path_to_train_info = os.path.join(self.path_to_model, 'train_info')
                self.logger.warning("Deleting files from folder: %s", path_to_train_info)

                for file in os.listdir(path_to_train_info):
                    os.remove(path_to_train_info)

                if os.path.exists(os.path.join(self.path_to_model,
                                               self.doc_vectors_name)):
                    self.logger.info("Updating existing file with training vectors in folder: %s",
                                     self.path_to_model)
                    doc_vectors_cur = pd.read_csv(os.path.join(self.path_to_model,
                                                               self.doc_vectors_name),
                                                  index_col=0)
                    doc_vectors_cur.index = pd.to_datetime(doc_vectors_cur.index)
                    doc_vectors = pd.concat([doc_vectors_cur, doc_vectors])
                    doc_vectors.to_csv(os.path.join(self.path_to_model,
                                                    self.doc_vectors_name))
                else:
                    self.logger.info("Saving new training vectors to folder: %s",
                                     self.path_to_model)
                    doc_vectors.to_csv(os.path.join(self.path_to_model,
                                                    self.doc_vectors_name))
        else:
            self.logger.info("Updating file with training vectors")
            doc_vectors = pd.read_csv(os.path.join(self.path_to_model,
                                                   self.doc_vectors_name),
                                      index_col=0)
            doc_vectors.index = pd.to_datetime(doc_vectors.index)

        self.logger.info("Start calculating mean distances with KNN")
        doc_vectors.dropna(inplace=True)
        self.mean_distances = self.__calc_mean_distances(doc_vectors.iloc[:, :self.vector_size],
                                                         mode='train')
        self.treshold_score = np.quantile(self.mean_distances, self.quantile_mean_dist)
        self.fitted = True
        self.save_model()

    def get_mean_distances(self):
        """Mean distances getter function"""
        if self.mean_distances is None:
            self.logger.error("mean_distances wasn't calculated")
            raise ValueError("mean_distances wasn't calculated")
        return self.mean_distances

    def get_treshold_score(self):
        """Treshold score getter function"""
        if self.treshold_score is None:
            self.logger.error("treshold_score wasn't calculated")
            raise ValueError("treshold_score wasn't calculated")
        return self.treshold_score

    def save_model(self) -> None:
        """Model saving function"""
        self.logger.info("Saving log analysis model to folder: %s", self.path_to_model)
        log_analysis_model = {"nlp_model_name": self.nlp_model_name,
                              "use_words_tfidf": self.use_words_tfidf,
                              "use_logs_tfidf": self.use_logs_tfidf,
                              "use_logs_patterns": self.use_logs_patterns,
                              "tags_weights": self.tags_weights,
                              "patterns_weights": self.patterns_weights,
                              "vector_size": self.vector_size,
                              "window": self.window,
                              "min_count": self.min_count,
                              "epochs": self.epochs,
                              "time_interval": self.time_interval,
                              "n_workers": self.n_workers,
                              "n_nearest_nbrs": self.n_nearest_nbrs,
                              "quantile_mean_dist": self.quantile_mean_dist,
                              "save_train_info": self.save_train_info,
                              "fitted": self.fitted,
                              "knn_model_name": self.knn_model_name,
                              "doc_vectors_name": self.doc_vectors_name,
                              "treshold_score": self.treshold_score,
                              "mean_distances": self.mean_distances.to_json()}

        log_analysis_model_path = os.path.join(self.path_to_model, self.log_analysis_model_name)
        with open(log_analysis_model_path, mode="w", encoding='utf-8') as opened_file:
            json.dump(log_analysis_model, opened_file, indent=True)

    def predict(self,
                path_to_results: str,
                path_to_files: Optional[list] = None,
                skip_preprocessing: Optional[bool] = False,
                skip_calc_vectors: Optional[bool] = False,
                calc_logs_importance: Optional[bool] = False,
                save_test_info: Optional[bool] = True,
                parallel_mode: Optional[bool] = False) -> None:
        """Test data prediction function"""
        if not self.fitted:
            self.logger.error("Model not fitted")
            raise SystemError("Model not fitted")
        if (path_to_files is None) & ((skip_calc_vectors is False) & (skip_preprocessing is False)):
            self.logger.error("skip_calc_vectors or skip_preprocessing must be True if "
                              "path_to_data or files is None")
            raise ValueError("skip_calc_vectors or skip_preprocessing must be True if "
                             "path_to_data or files is None")
        if (path_to_files is not None) & ((skip_calc_vectors is True) | \
                                          (skip_preprocessing is True)):
            self.logger.error("skip_calc_vectors or skip_preprocessing must be False if "
                              "path_to_data or files is not None")
            raise ValueError("skip_calc_vectors or skip_preprocessing must be False if "
                             "path_to_data or files is not None")
        if (skip_calc_vectors is True) & (skip_preprocessing is True):
            self.logger.error("skip_calc_vectors and skip_preprocessing cannot be True "
                              "at the same time")
            raise ValueError("skip_calc_vectors and skip_preprocessing cannot be True "
                             "at the same time")
        if (save_test_info is False) & (skip_preprocessing is True):
            self.logger.error("save_test_info must be True when skip_preprocessing is True")
            raise ValueError("save_test_info must be True when skip_preprocessing is True")

        if (calc_logs_importance is True) & (skip_calc_vectors is True):
            self.logger.error("skip_calc_vectors must be False when calc_logs_importance is True")
            raise ValueError("skip_calc_vectors must be False when calc_logs_importance is True")

        if (not skip_calc_vectors) & (not skip_preprocessing):
            for path_to_file in path_to_files:
                self.logger.info("Start inference for file: %s", path_to_file)

                self.logger.info("Start reading log file: %s", path_to_file)
                logs = read_logs(path_to_file, "HDFS") # hardcode
                self.logger.info("Start preprocessing log file: %s", path_to_file)
                start_time = time.time()
                if parallel_mode:
                    self.logger.info("Using %s workers for parallel calculation", self.n_workers)
                    logs_df = self.__parallel_log_preprocessing(logs)
                else:
                    logs_df = self.__log_preprocessing(logs, dataset_type="HDFS")
                logs_df = self.__sorting_check(logs_df)
                self.logger.info("Finished preprocessing log file, time: %s sec",
                                 np.round(time.time() - start_time, 2))

                self.logger.info("Using log analysis model: %s", self.path_to_model)
                log_vectorizer = LogVectorizer(download_model=True,
                                               model_path=self.path_to_model,
                                               path_to_semantic_model=self.path_to_semantic_model,
                                               nlp_model_name=self.nlp_model_name,
                                               use_words_tfidf=self.use_words_tfidf,
                                               use_logs_tfidf=self.use_logs_tfidf,
                                               use_logs_patterns=self.use_logs_patterns,
                                               tags_weights=self.tags_weights,
                                               patterns_weights=self.patterns_weights,
                                               time_interval=self.time_interval,
                                               log_file=self.log_file)
                self.logger.info("Start test vectors calculation")
                start_time = time.time()
                doc_vectors, bol_corpus, bow_corpus, logs_split_df, logs_importance_corpus = \
                        log_vectorizer.calc_test_vectors(logs_df,
                                                         calc_logs_importance=calc_logs_importance,
                                                         parallel_mode=parallel_mode)
                self.logger.info("Finished test vectors calculation, time: %s sec",
                                 np.round(time.time() - start_time, 2))
                gc.collect()
                del logs_df, logs
                if not save_test_info:
                    del bol_corpus, bow_corpus

                if not os.path.exists(path_to_results):
                    self.logger.info("Results folder not found, create new results folder: %s",
                                     path_to_results)
                    os.makedirs(path_to_results)
                    if save_test_info:
                        os.makedirs(os.path.join(path_to_results, "test_info"))

                if save_test_info:
                    self.logger.info("Saving bags of words and logs corpuses to folder: %s",
                                     os.path.join(path_to_results, "test_info"))
                    if len(re.findall("[0-9]", path_to_file)) != 0:
                        suffix = re.findall("[0-9]", path_to_file)[0]
                    else:
                        suffix = "1"

                    # save bol corpus
                    bol_corpus_path = os.path.join(path_to_results,
                                                   "test_info",
                                                   f"bol_corpus_{suffix}.gz")
                    with gzip.open(bol_corpus_path, mode='wb') as opened_file:
                        opened_file.write(json.dumps(bol_corpus, indent=True).encode('utf-8'))

                    # save bow corpus
                    bow_corpus_path = os.path.join(path_to_results,
                                                   "test_info",
                                                   f"bow_corpus_{suffix}.gz")
                    with gzip.open(bow_corpus_path, mode='wb') as opened_file:
                        opened_file.write(json.dumps(bow_corpus, indent=True).encode('utf-8'))

                    # save logs_split_df
                    logs_split_df_path = os.path.join(path_to_results,
                                                      "test_info",
                                                      f"logs_split_df_{suffix}.csv")
                    logs_split_df.to_csv(logs_split_df_path, encoding='utf-8')

                time_intervals_dict_path = os.path.join(path_to_results,
                                                        "time_intervals_dict.txt")
                self.logger.info("Saving time intervals dictionary to: %s",
                                 time_intervals_dict_path)
                time_intervals_dict = {os.path.basename(path_to_file): [str(doc_vectors.index[0]),
                                                                        str(doc_vectors.index[-1])]}
                if os.path.exists(time_intervals_dict_path):
                    with open(time_intervals_dict_path, mode="r", encoding='utf-8') as opened_file:
                        time_intervals_dict_cur = json.load(opened_file, parse_int=int)
                    time_intervals_dict_cur.update(time_intervals_dict)
                    time_intervals_dict = time_intervals_dict_cur

                with open(time_intervals_dict_path, mode="w", encoding='utf-8') as opened_file:
                    json.dump(time_intervals_dict, opened_file, indent=True)

                if os.path.exists(os.path.join(path_to_results,
                                               self.doc_vectors_name)):
                    self.logger.info("Updating file with test vectors: %s",
                                     os.path.join(path_to_results, self.doc_vectors_name))
                    test_doc_vectors_cur = pd.read_csv(os.path.join(path_to_results,
                                                                    self.doc_vectors_name),
                                                   index_col=0)
                    test_doc_vectors_cur.index = pd.to_datetime(test_doc_vectors_cur.index)

                    doc_vectors = pd.concat([test_doc_vectors_cur, doc_vectors])
                    doc_vectors.fillna(0, inplace=True)
                    doc_vectors = pd.concat([doc_vectors.iloc[:, :self.vector_size],
                                             doc_vectors.iloc[:, self.vector_size:].astype(int)],
                                            axis=1)
                    doc_vectors.to_csv(os.path.join(path_to_results,
                                                    self.doc_vectors_name))
                else:
                    self.logger.info("Create new file with testing vectors: %s",
                                     os.path.join(path_to_results, self.doc_vectors_name))
                    doc_vectors.to_csv(os.path.join(path_to_results,
                                                    self.doc_vectors_name))

        if skip_preprocessing:
            self.logger.info("Start inference with ready bags of words and logs files")
            log_vectorizer = LogVectorizer(download_model=True,
                                           model_path=self.path_to_model,
                                           path_to_semantic_model=self.path_to_semantic_model,
                                           nlp_model_name=self.nlp_model_name,
                                           use_words_tfidf=self.use_words_tfidf,
                                           use_logs_tfidf=self.use_logs_tfidf,
                                           use_logs_patterns=self.use_logs_patterns,
                                           tags_weights=self.tags_weights,
                                           patterns_weights=self.patterns_weights,
                                           time_interval=self.time_interval,
                                           log_file=self.log_file)
            self.logger.info("Start test vectors calculation")
            start_time = time.time()
            doc_vectors, _, _, _, logs_importance_corpus = log_vectorizer.calc_test_vectors(
                                                    path_to_results=path_to_results,
                                                    calc_logs_importance=calc_logs_importance,
                                                    parallel_mode=parallel_mode)
            self.logger.info("Finished test vectors calculation, time: %s sec",
                             np.round(time.time() - start_time, 2))
            doc_vectors.to_csv(os.path.join(path_to_results,
                                            self.doc_vectors_name))

        if skip_calc_vectors:
            self.logger.info("Uploading file with testing vectors from: %s",
                             os.path.join(path_to_results, self.doc_vectors_name))
            doc_vectors = pd.read_csv(os.path.join(path_to_results,
                                                   self.doc_vectors_name),
                                    index_col=0)
            doc_vectors.index = pd.to_datetime(doc_vectors.index)

        self.logger.info("Start calculating mean distances with KNN")
        doc_vectors.dropna(inplace=True)
        mean_distances = self.__calc_mean_distances(doc_vectors.iloc[:, :self.vector_size],
                                                    mode='test')
        if calc_logs_importance:
            return mean_distances, logs_importance_corpus
        return mean_distances

    # def __find_file_using_time(self,
    #                            timestamp: str,
    #                            path_to_results: str) -> Tuple[str, str, str]:
    #     time_intervals_dict_path = os.path.join(path_to_results,
    #                                             "time_intervals_dict.txt")
    #     self.logger.info("Reading dictionary with time intervals from: %s",
    #                      time_intervals_dict_path)
    #     with open(time_intervals_dict_path, mode="r", encoding='utf-8') as opened_file:
    #         time_intervals_dict = json.load(opened_file, parse_int=int)

    #     path_to_file_return = None
    #     ts_start = None
    #     ts_end = None
    #     for path_to_file, ts in time_intervals_dict.items():
    #         ts = np.array(ts, dtype='datetime64')
    #         timestamp = np.datetime64(timestamp, 'us')

    #         min_ts_in_file = ts[0]
    #         max_ts_in_file = ts[1] + np.timedelta64(int(self.time_interval), 'm')

    #         if (timestamp >= min_ts_in_file) & (timestamp < max_ts_in_file):
    #             path_to_file_return = path_to_file
    #             ts_start = timestamp
    #             ts_end = timestamp + np.timedelta64(int(self.time_interval), 'm')

    #             ts_start = str(ts_start).replace('T', ' ')
    #             ts_end = str(ts_end).replace('T', ' ')
    #     if path_to_file_return is None:
    #         self.logger.error("Time interval not found")
    #         raise ValueError("Time interval not found")
    #     self.logger.info("Time interval from %s to %s was found in file %s",
    #                      ts_start, ts_end, path_to_file_return)
    #     return path_to_file_return, ts_start, ts_end

    # def __group_col(self,
    #                 df: pd.DataFrame,
    #                 col: str) -> pd.Series:
    #     return df.groupby(['log_pattern', 'log_importance'],
    #                       observed=False)[col].apply(list).reset_index()[col].\
    #                                                                 apply(lambda x: list(set(x)))

    # def logs_importance(self,
    #                     timestamp: str,
    #                     path_to_results: str,
    #                     path_to_test: str = None) -> pd.DataFrame:
    #     """Logs importance calculation function"""
    #     if not self.fitted:
    #         self.logger.error("Model not fitted")
    #         raise SystemError("Model not fitted")

    #     path_to_file_return, ts_start, ts_end = self.__find_file_using_time(timestamp,
    #                                                                         path_to_results)
    #     if path_to_test is not None:
    #         path_to_file_return = os.path.join(path_to_test, path_to_file_return)
    #         self.logger.info("Start reading log file: %s", path_to_file_return)
    #         logs_list = read_logs(file_name=path_to_file_return,
    #                               time_stamp_start=ts_start,
    #                               time_stamp_end=ts_end)
    #         logs_df = self.__log_preprocessing(logs_list)
    #         logs_df = self.__sorting_check(logs_df)
    #     else:
    #         if not os.path.exists(os.path.join(path_to_results, "test_info")):
    #             self.logger.error("Folder with bag of logs corpus not found")
    #             raise ValueError("Folder with bag of logs corpus not found")
    #         self.logger.info("Start loading bag of logs corpus from: %s",
    #                          os.path.join(path_to_results, "test_info"))
    #         files_list = os.listdir(os.path.abspath(os.path.join(path_to_results, "test_info")))
    #         files = sorted([file for file in files_list if file.startswith("bol_corpus")])

    #         bol_corpus_file_name = None
    #         for file in files:
    #             if path_to_file_return.find(file.split('_')[-1].split('.')[0]) != -1:
    #                 bol_corpus_file_name = file

    #         if bol_corpus_file_name is not None:
    #             log_corpus_path = os.path.abspath(os.path.join(path_to_results,
    #                                                             "test_info",
    #                                                             bol_corpus_file_name))
    #             with gzip.open(log_corpus_path, mode='rb') as file:
    #                 bol_corpus = json.loads(file.read().decode('utf-8'))
    #         else:
    #             self.logger.error("Time interval not found")
    #             raise ValueError("Time interval not found")

    #         ts = np.array([ts_start], dtype='datetime64[s]')[0].astype('str')
    #         logs = []
    #         for log_pattern, n_logs in bol_corpus[ts].items():
    #             logs.extend([log_pattern] * n_logs)
    #         logs_df = pd.DataFrame(logs, index=np.full(len(logs), ts), columns=['log_pattern'])
    #         logs_df.index = pd.to_datetime(logs_df.index)
    #         logs_df['tag'] = logs_df['log_pattern'].apply(lambda x: re.findall("<[A-Za-z]+>", x)[0])
    #         logs_list = []

    #     temp_df = pd.DataFrame(np.full((1, logs_df.shape[1]), ''),
    #             index=np.array([logs_df.index[0] + np.timedelta64(int(self.time_interval), 'm')],
    #                             dtype='datetime64'), columns=logs_df.columns)
    #     logs_df = pd.concat([logs_df, temp_df])

    #     log_vectorizer = LogVectorizer(download_model=True,
    #                                    model_path=self.path_to_model,
    #                                    path_to_semantic_model=self.path_to_semantic_model,
    #                                    nlp_model_name=self.nlp_model_name,
    #                                    use_words_tfidf=self.use_words_tfidf,
    #                                    use_logs_tfidf=self.use_logs_tfidf,
    #                                    use_logs_patterns=self.use_logs_patterns,
    #                                    tags_weights=self.tags_weights,
    #                                    patterns_weights=self.patterns_weights,
    #                                    time_interval=self.time_interval)

    #     self.logger.info("Start test vector calculation")
    #     doc_vectors, _, _, _, _ = log_vectorizer.calc_test_vectors(logs_df)

    #     doc_vectors.dropna(inplace=True)
    #     mean_distance = self.__calc_mean_distances(doc_vectors.iloc[:, :self.vector_size],
    #                                                mode='test')

    #     ts = str(np.array(doc_vectors.index, dtype='datetime64[s]')[0])
    #     test_doc_vector = doc_vectors.loc[ts].values[:self.vector_size]
    #     logs_df = logs_df[:-1]
    #     dataset_len = len(logs_df)
    #     log_vectors = np.zeros((dataset_len, self.vector_size))
    #     logs_importance = np.zeros(dataset_len)
    #     logs = []
    #     tags = []

    #     self.logger.info("Start logs importance calculation")
    #     for i in range(dataset_len):
    #         log_vector = np.zeros(self.vector_size)
    #         log_num_words = 0
    #         tag = logs_df["tag"].iloc[i]
    #         log = logs_df["log_pattern"].iloc[i]
    #         for word in log.split(tag)[1].split():
    #             if ((self.nlp_model_name == "word2vec") & (word in log_vectorizer.nlp_model.wv)) | \
    #                 (self.nlp_model_name == "fasttext"):
    #                 if self.use_words_tfidf:
    #                     log_vector += log_vectorizer.nlp_model.wv[word] * \
    #                                     log_vectorizer.words_tfidf_dict[ts][word]
    #                 else:
    #                     log_vector += log_vectorizer.nlp_model.wv[word]
    #                 log_num_words += 1
    #         if self.use_logs_tfidf:
    #             log_vector *= log_vectorizer.logs_tfidf_dict[ts][log]
    #         if self.use_logs_patterns:
    #             log_vector *= log_vectorizer.log_weight_calc(log, tag)
    #         if log_num_words != 0:
    #             log_vector /= log_num_words

    #         log_vectors[i] = log_vector
    #         logs.append(log)
    #         tags.append(tag)
    #     log_vectors /= dataset_len

    #     for i in range(dataset_len):
    #         logs_importance[i] = np.dot(test_doc_vector, log_vectors[i]) / \
    #                                 np.linalg.norm(test_doc_vector)**2

    #     self.logger.info("Start logs importance DataFrame calculation")
    #     logs_importance_df = pd.DataFrame(logs_importance, columns=['log_importance'])
    #     logs_importance_df['log_pattern'] = logs
    #     logs_importance_df['tag'] = tags

    #     logs_importance_groups = logs_importance_df.groupby('log_pattern', observed=False).\
    #                                                         sum('log_importance').reset_index()
    #     logs_importance_groups = pd.merge(logs_importance_groups,
    #                                       logs_importance_df.iloc[:, 1:].drop_duplicates(),
    #                                       on='log_pattern',
    #                                       how='left')
    #     logs_importance_groups_ = logs_importance_groups.groupby(['log_pattern', 'log_importance'],
    #                             observed=False)['tag'].count().reset_index().iloc[:, :2]
    #     logs_importance_groups_['tag'] = self.__group_col(logs_importance_groups,
    #                                                                 'tag')
    #     logs_importance_groups = logs_importance_groups_

    #     logs_importance_groups = logs_importance_groups[logs_importance_groups['log_pattern'] != '']
    #     logs_importance_groups['quantity'] = logs_importance_df.groupby('log_pattern',
    #                                                 observed=False).count()['log_importance'].values
    #     logs_importance_groups['% of all'] = logs_importance_groups['quantity'] / \
    #                                             logs_importance_groups['quantity'].sum() * 100
    #     logs_importance_groups = logs_importance_groups.sort_values('log_importance',
    #                                                                 ascending=False,
    #                                                                 ignore_index=True)
    #     if logs_importance_groups["tag"].apply(len).max() == 1:
    #         logs_importance_groups["tag"] = logs_importance_groups["tag"].apply(lambda x: x[0])
    #     return logs_importance_groups, logs_list, path_to_file_return, ts_start, ts_end, \
    #            doc_vectors, mean_distance.values[0]
